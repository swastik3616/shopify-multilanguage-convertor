<s-stack direction="inline" gap="base">
  <s-clickable-chip color="base" accessibilityLabel="Filter by active products">
    Active
  </s-clickable-chip>
  <s-clickable-chip
    color="subdued"
    accessibilityLabel="Filter by draft products"
  >
    Draft
  </s-clickable-chip>
  <s-clickable-chip
    color="strong"
    accessibilityLabel="Filter by archived products"
  >
    Archived
  </s-clickable-chip>
</s-stack>