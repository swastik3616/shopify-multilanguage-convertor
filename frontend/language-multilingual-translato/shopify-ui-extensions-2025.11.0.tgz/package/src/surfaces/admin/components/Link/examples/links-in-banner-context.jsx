<s-banner tone="warning">
  <s-paragraph>
    Your inventory for "Vintage t-shirt" is running low (3 remaining).  <s-link>Restock inventory</s-link>
  </s-paragraph>
</s-banner>