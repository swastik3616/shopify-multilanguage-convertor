<s-stack gap="base">
  <s-date-field
    label="Creation date"
    name="createdDate"
    value="2024-01-01"
    readOnly
   />

  <s-date-field
    label="Archived date"
    name="archivedDate"
    value="2024-02-15"
    disabled
   />
</s-stack>