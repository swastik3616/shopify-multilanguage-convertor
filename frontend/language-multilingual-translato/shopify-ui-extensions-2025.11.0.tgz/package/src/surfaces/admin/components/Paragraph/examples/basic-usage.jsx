<s-paragraph>
  Track inventory across all your retail locations in real-time.
</s-paragraph>