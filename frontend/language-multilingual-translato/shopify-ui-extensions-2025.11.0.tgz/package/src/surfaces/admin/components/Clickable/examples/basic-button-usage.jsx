<s-clickable border="base" padding="base">
  Click me
</s-clickable>