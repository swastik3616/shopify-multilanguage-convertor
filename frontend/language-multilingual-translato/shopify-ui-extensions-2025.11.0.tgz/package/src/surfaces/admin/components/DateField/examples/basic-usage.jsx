<s-date-field
  label="Order date"
  name="orderDate"
  placeholder="Select date"
 />