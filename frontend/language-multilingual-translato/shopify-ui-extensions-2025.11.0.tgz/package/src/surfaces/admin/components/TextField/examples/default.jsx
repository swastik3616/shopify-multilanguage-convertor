<s-text-field
  label="Store name"
  value="Jaded Pixel"
  placeholder="Become a merchant"
 />