<s-search-field
  label="Search customers"
  name="customerSearch"
  disabled
  placeholder="Search is currently unavailable"
 />