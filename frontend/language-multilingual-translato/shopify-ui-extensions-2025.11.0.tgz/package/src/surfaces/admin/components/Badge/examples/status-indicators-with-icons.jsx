<s-stack gap="base">
  {/* Product status */}
  <s-stack direction="inline" gap="base">
    <s-badge tone="success" icon="view">
      Active
    </s-badge>
    <s-badge tone="warning" icon="clock">
      Scheduled
    </s-badge>
    <s-badge tone="critical">Archived</s-badge>
  </s-stack>

  {/* Inventory status */}
  <s-stack direction="inline" gap="base">
    <s-badge tone="success">In stock</s-badge>
    <s-badge tone="warning" icon="alert-triangle">
      Low stock
    </s-badge>
    <s-badge tone="critical">Out of stock</s-badge>
  </s-stack>
</s-stack>