<s-text-area
  label="Care instructions"
  rows={6}
  details="Detailed care instructions help customers maintain their purchases and reduce returns."
  placeholder="Provide washing, storage, and maintenance instructions..."
  autocomplete="off"
 />