<s-thumbnail
  src="https://cdn.shopify.com/static/sample-product/House-Plant1.png"
  alt="Product preview"
  size="base"
 />