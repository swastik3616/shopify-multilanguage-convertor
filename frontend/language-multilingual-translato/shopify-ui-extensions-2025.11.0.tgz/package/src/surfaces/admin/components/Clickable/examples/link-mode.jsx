<s-clickable href="javascript:void(0)" target="_blank">
  Visit Shopify
</s-clickable>