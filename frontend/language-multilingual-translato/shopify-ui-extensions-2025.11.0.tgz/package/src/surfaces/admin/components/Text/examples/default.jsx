<s-paragraph>
  <s-text type="strong">Name: </s-text>
  <s-text>Jane Doe</s-text>
</s-paragraph>
