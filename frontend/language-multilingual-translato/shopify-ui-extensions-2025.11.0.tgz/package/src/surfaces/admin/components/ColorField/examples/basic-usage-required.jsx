<s-stack gap="base">
  <s-color-field label="Brand color" value="#FF0000" required />
</s-stack>