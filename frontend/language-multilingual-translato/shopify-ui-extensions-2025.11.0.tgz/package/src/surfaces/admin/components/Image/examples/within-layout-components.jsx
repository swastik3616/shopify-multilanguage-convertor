<s-grid gridTemplateColumns="repeat(3, 150px)" gap="base" alignItems="center">
  <s-image
    src="https://cdn.shopify.com/static/sample-product/House-Plant1.png"
    alt="Main view"
    aspectRatio="1/1"
    objectFit="cover"
    borderRadius="base"
    inlineSize="fill"
   />
  <s-image
    src="https://cdn.shopify.com/static/sample-product/House-Plant1.png"
    alt="Side view"
    aspectRatio="1/1"
    objectFit="cover"
    borderRadius="base"
    inlineSize="fill"
   />
  <s-image
    src="https://cdn.shopify.com/static/sample-product/House-Plant1.png"
    alt="Detail view"
    aspectRatio="1/1"
    objectFit="cover"
    borderRadius="base"
    inlineSize="fill"
   />
</s-grid>