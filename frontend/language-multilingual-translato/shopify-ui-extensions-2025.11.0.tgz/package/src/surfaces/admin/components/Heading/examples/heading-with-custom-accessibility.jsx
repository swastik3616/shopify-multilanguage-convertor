<s-heading accessibilityRole="presentation" accessibilityVisibility="hidden">
  Sale badge
</s-heading>