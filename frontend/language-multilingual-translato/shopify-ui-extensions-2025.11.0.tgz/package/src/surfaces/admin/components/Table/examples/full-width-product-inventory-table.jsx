<s-section padding="none">
  <s-table>
    <s-table-header-row>
      <s-table-header listSlot="primary">Product</s-table-header>
      <s-table-header listSlot="kicker">SKU</s-table-header>
      <s-table-header listSlot="inline">Status</s-table-header>
      <s-table-header listSlot="labeled" format="numeric">Inventory</s-table-header>
      <s-table-header listSlot="labeled" format="currency">Price</s-table-header>
      <s-table-header listSlot="labeled">Last updated</s-table-header>
    </s-table-header-row>

    <s-table-body>
      <s-table-row>
        <s-table-cell>Water bottle</s-table-cell>
        <s-table-cell>WB-001</s-table-cell>
        <s-table-cell>
          <s-badge tone="success">Active</s-badge>
        </s-table-cell>
        <s-table-cell>128</s-table-cell>
        <s-table-cell>$24.99</s-table-cell>
        <s-table-cell>2 hours ago</s-table-cell>
      </s-table-row>
      <s-table-row>
        <s-table-cell>T-shirt</s-table-cell>
        <s-table-cell>TS-002</s-table-cell>
        <s-table-cell>
          <s-badge tone="warning">Low stock</s-badge>
        </s-table-cell>
        <s-table-cell>15</s-table-cell>
        <s-table-cell>$19.99</s-table-cell>
        <s-table-cell>1 day ago</s-table-cell>
      </s-table-row>
      <s-table-row>
        <s-table-cell>Cutting board</s-table-cell>
        <s-table-cell>CB-003</s-table-cell>
        <s-table-cell>
          <s-badge tone="critical">Out of stock</s-badge>
        </s-table-cell>
        <s-table-cell>0</s-table-cell>
        <s-table-cell>$34.99</s-table-cell>
        <s-table-cell>3 days ago</s-table-cell>
      </s-table-row>
      <s-table-row>
        <s-table-cell>Notebook set</s-table-cell>
        <s-table-cell>NB-004</s-table-cell>
        <s-table-cell>
          <s-badge tone="success">Active</s-badge>
        </s-table-cell>
        <s-table-cell>245</s-table-cell>
        <s-table-cell>$12.99</s-table-cell>
        <s-table-cell>5 hours ago</s-table-cell>
      </s-table-row>
      <s-table-row>
        <s-table-cell>Stainless steel straws</s-table-cell>
        <s-table-cell>SS-005</s-table-cell>
        <s-table-cell>
          <s-badge tone="success">Active</s-badge>
        </s-table-cell>
        <s-table-cell>89</s-table-cell>
        <s-table-cell>$9.99</s-table-cell>
        <s-table-cell>1 hour ago</s-table-cell>
      </s-table-row>
    </s-table-body>
  </s-table>
</s-section>