<s-stack gap="base">
  <s-box padding="base">
    <s-text>150 orders</s-text>
  </s-box>
  <s-divider />
  <s-box padding="base">
    <s-text>$2,400 revenue</s-text>
  </s-box>
  <s-divider />
  <s-box padding="base">
    <s-text>89 customers</s-text>
  </s-box>
</s-stack>
