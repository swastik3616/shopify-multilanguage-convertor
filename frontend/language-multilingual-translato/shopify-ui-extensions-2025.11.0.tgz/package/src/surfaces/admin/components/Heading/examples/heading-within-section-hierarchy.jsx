<s-section>
  <s-heading>Order information</s-heading>
  {/* Renders as h2 */}
  <s-section>
    <s-heading>Shipping details</s-heading>
    {/* Renders as h3 */}
    <s-section>
      <s-heading>Tracking updates</s-heading>
      {/* Renders as h4 */}
    </s-section>
  </s-section>
</s-section>