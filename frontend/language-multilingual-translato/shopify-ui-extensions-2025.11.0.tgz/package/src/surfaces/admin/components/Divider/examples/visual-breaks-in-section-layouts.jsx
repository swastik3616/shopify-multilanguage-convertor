<s-box padding="large-400" background="base">
  <s-stack gap="base">
    <s-heading>Order summary</s-heading>
    <s-text>3 items</s-text>
    <s-divider />
    <s-heading>Shipping address</s-heading>
    <s-text>123 Main Street, Toronto ON</s-text>
    <s-divider />
    <s-heading>Payment method</s-heading>
    <s-text>•••• 4242</s-text>
  </s-stack>
</s-box>
