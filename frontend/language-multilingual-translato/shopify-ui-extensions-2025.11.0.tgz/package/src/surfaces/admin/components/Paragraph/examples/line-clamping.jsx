<s-box inlineSize="300px">
  <s-paragraph lineClamp={1}>
    Premium organic cotton t-shirt featuring sustainable manufacturing
    processes, ethically sourced materials, and carbon-neutral shipping.
    Available in multiple colors and sizes with customization options for your
    brand.
  </s-paragraph>
</s-box>