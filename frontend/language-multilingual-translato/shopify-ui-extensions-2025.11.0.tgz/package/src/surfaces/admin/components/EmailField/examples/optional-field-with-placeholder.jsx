<s-stack gap="base">
  <s-email-field
    label="Alternate email"
    placeholder="secondary@example.com"
    details="Additional email for notifications"
   />
</s-stack>