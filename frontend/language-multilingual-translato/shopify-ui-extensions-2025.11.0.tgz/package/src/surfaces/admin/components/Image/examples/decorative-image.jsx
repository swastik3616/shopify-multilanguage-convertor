<s-image
  src="https://cdn.shopify.com/static/sample-product/House-Plant1.png"
  alt=""
  accessibilityRole="presentation"
  objectFit="cover"
 />