<s-number-field
  label="Quantity"
  details="Number of items in stock"
  placeholder="0"
  step={5}
  min={0}
  max={100}
/>
