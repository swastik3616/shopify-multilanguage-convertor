<s-paragraph accessibilityVisibility="exclusive">
  Table sorted by date, newest first.
</s-paragraph>