<s-stack gap="small">
    <s-text-field
    label="Phone number"
    prefix="+03"
    />
    <s-text-field
    label="Credit Card Number"
    value="1234 5678 9012 3456"
    suffix="VISA"
    />
</s-stack>