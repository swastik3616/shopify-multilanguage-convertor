<s-chip color="base" accessibilityLabel="Product status indicator">
  Active
</s-chip>