<s-stack gap="base">
  {/* Inventory status section */}
  <s-box
    padding="base"
    background="base"
    borderRadius="base"
    borderWidth="base"
    borderColor="base"
  >
    <s-stack gap="base">
      <s-box padding="small-100" background="subdued" borderRadius="small">
        <s-paragraph>In stock: 45 units</s-paragraph>
      </s-box>
      <s-box padding="small-100" background="subdued" borderRadius="small">
        <s-paragraph>Low stock alert: 5 units</s-paragraph>
      </s-box>
    </s-stack>
  </s-box>

  {/* Product information section */}
  <s-box
    padding="base"
    background="base"
    borderRadius="base"
    borderWidth="base"
    borderColor="base"
  >
    <s-stack gap="base">
      <s-heading>Product sales</s-heading>
      <s-paragraph color="subdued">No recent sales of this product</s-paragraph>
      <s-link>View details</s-link>
    </s-stack>
  </s-box>
</s-stack>
