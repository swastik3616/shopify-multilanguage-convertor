import type {Market} from '../api/standard/standard';
import type {RenderExtensionTarget} from '../extension-targets';

import {useApi} from './api';
import {useSubscription} from './subscription';

/**
 * Returns the market of the checkout, and automatically re-renders
 * your component if it changes.
 * @publicDocs
 */
export function useLocalizationMarket<
  Target extends RenderExtensionTarget = RenderExtensionTarget,
>(): Market | undefined {
  const {localization} = useApi<Target>();

  return useSubscription(localization.market);
}
