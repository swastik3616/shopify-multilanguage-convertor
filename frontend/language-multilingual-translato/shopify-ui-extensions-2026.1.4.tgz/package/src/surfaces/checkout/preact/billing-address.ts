import type {RenderExtensionTarget} from '../extension-targets';
import type {MailingAddress} from '../api/shared';

import {ScopeNotGrantedError} from './errors';
import {useApi} from './api';
import {useSubscription} from './subscription';

/**
 * Returns the proposed `billingAddress` applied to the checkout.
 * @publicDocs
 */
export function useBillingAddress<
  Target extends RenderExtensionTarget = RenderExtensionTarget,
>(): MailingAddress | undefined {
  const billingAddress = useApi<Target>().billingAddress;

  if (!billingAddress) {
    throw new ScopeNotGrantedError(
      'Using billing address requires having billing address permissions granted to your app.',
    );
  }

  return useSubscription(billingAddress);
}
