import type {Capability} from '../api/standard/standard';

import {useSubscription} from './subscription';
import {useApi} from './api';

/**
 * Returns a list of an extension's granted capabilities.
 * @publicDocs
 */
export function useExtensionCapabilities(): Capability[] {
  return useSubscription(useApi().extension.capabilities);
}

/**
 * Returns whether or not a given capability of an extension is granted.
 * @publicDocs
 */
export function useExtensionCapability(capability: Capability): boolean {
  return useExtensionCapabilities().includes(capability);
}
