import type {RenderExtensionTarget} from '../extension-targets';
import type {Country} from '../../../shared';

import {useApi} from './api';
import {useSubscription} from './subscription';

/**
 * Returns the country of the checkout, and automatically re-renders
 * your component if the country changes.
 * @publicDocs
 */
export function useLocalizationCountry<
  Target extends RenderExtensionTarget = RenderExtensionTarget,
>(): Country | undefined {
  const {localization} = useApi<Target>();

  return useSubscription(localization.country);
}
