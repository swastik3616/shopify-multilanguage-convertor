import type {Metafield} from '../api';

import {CustomerAccountUIExtensionError} from './errors';

import {useMetafields} from './metafields';

interface MetafieldFilter {
  namespace: string;
  key: string;
}

/**
 * Returns a single filtered `Metafield` or `undefined`.
 * @arg {MetafieldFilter} - filter the list of returned metafields to a single metafield
 * @deprecated `useMetafield` is deprecated. Use `useAppMetafields` instead.
 */
export function useMetafield(filters: MetafieldFilter): Metafield | undefined {
  const {namespace, key} = filters;

  if (!namespace || !key) {
    throw new CustomerAccountUIExtensionError(
      'You must pass in both a namespace and key',
    );
  }

  const metafields = useMetafields({namespace, key});

  return metafields.length ? metafields[0] : undefined;
}
