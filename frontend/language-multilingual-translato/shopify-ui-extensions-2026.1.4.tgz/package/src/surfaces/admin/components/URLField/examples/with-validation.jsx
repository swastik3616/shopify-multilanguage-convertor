<s-url-field
  label="Company website"
  required
  minLength={10}
  maxLength={200}
  error="Please enter a valid website URL"
  />