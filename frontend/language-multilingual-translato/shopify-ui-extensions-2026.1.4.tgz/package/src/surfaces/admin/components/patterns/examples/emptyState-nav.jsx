<s-section>
  <s-stack alignItems="center" padding="large-600">
    <s-box maxInlineSize="200px">
      <s-image
        src="https://cdn.shopify.com/static/images/polaris/patterns/callout.png"
        alt="No puzzles illustration"
        aspectRatio="1/0.5"
      />
    </s-box>
    <s-heading>Create your first puzzle</s-heading>
    <s-paragraph>
      Get started by creating a puzzle template. You can customize the number of pieces, shape, and difficulty level.
    </s-paragraph>
    <s-button href="/app/puzzles/new">Create puzzle</s-button>
  </s-stack>
</s-section>
