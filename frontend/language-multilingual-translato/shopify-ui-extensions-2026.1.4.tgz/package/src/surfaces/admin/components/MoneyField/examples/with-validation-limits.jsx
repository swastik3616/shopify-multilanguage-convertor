<s-money-field
  label="Discount amount"
  value="5.00"
  min={0}
  max={100}
  details="Enter discount amount between $0 and $100"
/>