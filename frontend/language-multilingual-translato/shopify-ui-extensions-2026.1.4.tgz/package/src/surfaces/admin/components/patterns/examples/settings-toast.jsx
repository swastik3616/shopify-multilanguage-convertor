<form
  data-save-bar
  onSubmit={(event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const formEntries = Object.fromEntries(formData);
    console.log("Form data", formEntries);
    shopify.toast.show('Settings saved successfully');
  }}
  onReset={(event) => {
    console.log("Handle discarded changes if necessary");
  }}
>
  <s-section heading="Notifications">
    <s-select
      label="Notification frequency"
      name="notification-frequency"
    >
      <s-option value="immediately" selected>Immediately</s-option>
      <s-option value="hourly">Hourly digest</s-option>
      <s-option value="daily">Daily digest</s-option>
    </s-select>
    <s-choice-list
      label="Notification types"
      name="notifications-type"
      multiple
    >
      <s-choice value="new-order" selected>New order notifications</s-choice>
      <s-choice value="low-stock">Low stock alerts</s-choice>
      <s-choice value="customer-review">Customer review notifications</s-choice>
    </s-choice-list>
  </s-section>
</form>
