<s-money-field
  label="Price"
  value="19.99"
  min={0}
  max={1000}
 />