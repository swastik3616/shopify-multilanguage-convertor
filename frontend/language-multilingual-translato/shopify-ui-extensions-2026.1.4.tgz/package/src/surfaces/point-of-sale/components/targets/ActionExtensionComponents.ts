export type ActionExtensionComponents = 'Button';
